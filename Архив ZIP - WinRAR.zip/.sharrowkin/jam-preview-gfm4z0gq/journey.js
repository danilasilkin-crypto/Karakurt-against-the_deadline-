'use strict';
// Additional nights reuse movement/collisions, but own their objectives and clocks.
class NightJourney extends NightCampaign {
  reset() { super.reset(); this.night=0; this.linkLeft=0; this.targetLeft=0; this.crumb=null; this.crumbs=0; }
  get episode() { return NightEpisodes[this.night || 0]; }
  get mission() { return this.night && this.mode==='campaign' ? this.episode.chapters[this.chapter] : null; }
  get hunting() { return this.mission ? this.mission.kind==='hunt' : this.mode==='campaign' && this.chapter===3; }
  get threadMission() { return this.mission ? ['relay','weave'].includes(this.mission.kind) : this.mode==='campaign' && this.chapter===2; }
  get quota() { return this.mission?.quota ?? super.quota; }
  get limit() { return this.mission?.limit ?? super.limit; }
  get actionLabel() { return this.mission ? this.mission.label : super.actionLabel; }
  get targetLabel() { return this.mission ? this.mission.label : super.targetLabel; }
  get objective() { return this.mission ? `${this.mission.name} · ${this.done}/${this.quota}${this.linkLeft>0 ? ` · нить ${Math.ceil(this.linkLeft)}с` : this.targetLeft>0 ? ` · цель ${Math.ceil(this.targetLeft)}с` : ''}` : super.objective; }
  prepare(night=0) {
    if (!Number.isInteger(night) || !NightEpisodes[night]) return false;
    this.reset(); this.night=night; this.enterStage(0,false); this.phase='ready'; return true;
  }
  start(mode='campaign',night=this.night) {
    if (mode==='arcade') { super.start(mode); return; }
    this.prepare(night); this.phase='playing';
  }
  enterStage(level,card=true) {
    super.enterStage(level,card); this.linkLeft=0; this.targetLeft=this.mission?.volatile || 0; this.crumb=null;
    if (this.mission) {
      this.undo=null; this.spills=this.mission.spills ? [{row:0,col:3},{row:1,col:6},{row:2,col:5}] : [];
      this.silk=3; this.volley=0; this.selectMissionTarget();
    }
    this.checkpoint=this.snapshot();
  }
  snapshot() { return {...super.snapshot(),night:this.night || 0}; }
  restore(data) {
    const night=data && Object.hasOwn(data,'night') ? data.night : 0;
    if (!Number.isInteger(night) || !NightEpisodes[night]) return false;
    if (!super.restore(data)) return false;
    this.night=night; this.enterStage(data.level); return true;
  }
  selectMissionTarget() {
    const route=this.mission?.route;
    if (route) { const [row,col]=route[Math.min(this.done,route.length-1)]; this.target={row,col}; }
  }
  move(dr,dc) {
    const moved=super.move(dr,dc);
    if (moved && this.crumb?.row===this.row && this.crumb.col===this.col) {
      this.crumb=null; this.crumbs++; this.gainCharge(2); this.time=Math.min(this.limit,this.time+4); this.events.push('crumb');
    }
    return moved;
  }
  completeAction() {
    this.done++; this.score++; this.gainCharge(); this.events.push('objective');
    if (this.done>=this.quota) { this.advance(); return; }
    if (this.mission.route) this.selectMissionTarget(); else this.chooseTarget();
    this.targetLeft=this.mission.volatile || 0;
    if (this.mission.kind==='relay') this.linkLeft=this.mission.window;
  }
  typo() {
    if (!this.mission) return super.typo();
    if (this.phase!=='playing') return false;
    if (this.threadMission || this.hunting) { this.events.push('useweb'); return false; }
    if (this.row!==this.target.row || this.col!==this.target.col) { this.events.push('miss'); return false; }
    this.combo=this.comboTimer>0 ? this.combo+1 : 1; this.comboTimer=4; this.maxCombo=Math.max(this.maxCombo,this.combo);
    this.completeAction(); return true;
  }
  weave() {
    if (!this.mission) return super.weave();
    if (this.phase!=='playing') return false;
    if (this.threadMission && this.row===this.target.row && this.col===this.target.col) {
      this.anchors.push({...this.target}); this.events.push('anchor'); this.completeAction(); return true;
    }
    return NightGame.prototype.weave.call(this);
  }
  spawnStrikes() {
    if (!this.mission || this.volley%3!==2) return super.spawnStrikes();
    this.volley++; const columns=[this.col];
    if (this.night===2) columns.push((this.col+5)%10);
    for (const col of columns) for (let row=0;row<3;row++) this.strikes.push({row,col,delay:1.65,age:0,hit:false,blocked:false});
    this.nextStrike=2.7; this.events.push(this.night===1?'storm':'notifications');
  }
  tick(dt) {
    if (!this.mission) return super.tick(dt);
    if (this.phase!=='playing' || !Number.isFinite(dt) || dt<=0) return;
    this.stageTime+=dt; this.slow=Math.max(0,this.slow-dt);
    const rest=this.stageTime%24>=18;
    if (rest && !this.respite) {
      this.events.push('rest'); this.crumb={row:2,col:(this.chapter*3+2)%10};
    }
    this.respite=rest; if(rest) this.nextStrike=Math.max(this.nextStrike,dt+1); else this.crumb=null;
    if (this.linkLeft>0) {
      this.linkLeft=Math.max(0,this.linkLeft-dt);
      if (!this.linkLeft) { this.done=0; this.anchors=[]; this.selectMissionTarget(); this.events.push('link-lost'); }
    }
    if (this.mission.volatile) {
      this.targetLeft-=dt;
      if(this.targetLeft<=0) { this.chooseTarget(); this.targetLeft=this.mission.volatile; this.events.push('relocate'); }
    }
    if(Math.floor((this.stageTime-dt)/5)<Math.floor(this.stageTime/5) && this.silk<3) { this.silk++; this.events.push('silk'); }
    const blocked=this.blocked;
    NightGame.prototype.tick.call(this,dt);
    const gained=this.blocked-blocked;
    if(gained) {
      this.gainCharge(gained*2);
      if(this.hunting && this.phase==='playing') { this.done=Math.min(this.quota,this.done+gained); this.advance(); }
    }
  }
}
window.NightJourney=NightJourney;
