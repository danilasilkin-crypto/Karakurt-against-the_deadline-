"""Read-only runtime and old preview probe; does not start or modify services."""
import sys
import urllib.request
import socket
from pathlib import Path
from PIL import Image

print('Python:', sys.version.split()[0], 'Pillow:', Image.__version__)
for font in ['arial.ttf', 'arialbd.ttf', 'consola.ttf', 'consolab.ttf']:
    print(font, (Path('C:/Windows/Fonts') / font).is_file())
try:
    with urllib.request.urlopen('http://127.0.0.1:50955/index.html', timeout=2) as response:
        body = response.read().decode('utf-8')
        print('Previous preview:', response.status, 'project page:', 'menu-play' in body and 'Каракурт' in body)
except (OSError, socket.timeout) as error:
    print('Previous preview is not reachable:', str(error))
