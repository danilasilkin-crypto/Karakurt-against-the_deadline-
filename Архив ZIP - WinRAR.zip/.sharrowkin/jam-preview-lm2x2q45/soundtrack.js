'use strict';
// Original eight-bar theme «03:47». Eighth notes are scheduled on the audio
// clock, not animation frames. The game keeps the motif but adds a soft pulse.
const NightScore = (() => {
  const chords = [[57, 60, 64, 71], [53, 57, 60, 64], [48, 55, 59, 64], [55, 59, 62, 69]];
  const melody = [76, null, 79, null, 83, null, 79, 76, 74, null, 72, null, 71, null, 72, null,
    76, null, 79, null, 84, null, 83, 79, 76, null, 74, null, 72, null, 71, null];
  const hz = midi => 440 * 2 ** ((midi - 69) / 12);
  function play(audio, index, at) {
    const s = index % 64, bar = Math.floor(s / 8), beat = s % 8, chord = chords[Math.floor(bar / 2)];
    const running = audio.mode === 'playing', beatTime = 60 / (running ? 92 + audio.chapter * 8 : 76);
    const note = (midi, duration, volume, type = 'sine', pan = 0, attack = .012) =>
      audio.voice({ frequency: hz(midi), at, duration, volume, type, pan, attack, bus: 'music' });
    if (s % 16 === 0) chord.forEach((n, i) => note(n, beatTime * 7.5, .047, 'sine', (i - 1.5) * .25, .25));
    if (beat === 0 || beat === 4) note(chord[0] - 12, beatTime * 1.6, .15, 'sine');
    const lead = melody[Math.floor(s / 2)];
    if (s % 2 === 0 && lead !== null) {
      note(lead, .8, .09, 'triangle', bar % 2 ? .2 : -.2);
      note(lead + 12, .35, .018, 'sine', -.1);
    }
    if (running) {
      if (beat % 4 === 0) audio.voice({ frequency: 90, end: 40, duration: .17, volume: .16, at, bus: 'music' });
      if (beat % 2 === 1) audio.voice({ noise: true, duration: .035, volume: .045, filter: 3300, pan: .25, at, bus: 'music' });
      if (audio.chapter > 0 && beat % 2 === 0) note(chord[(beat / 2) % 4] + 12, .16, .045, 'triangle', -.25);
      if (audio.urgent && beat % 2 === 0) note(88, .055, .05, 'sine', .1);
    }
  }
  return { play };
})();
window.NightScore = NightScore;
