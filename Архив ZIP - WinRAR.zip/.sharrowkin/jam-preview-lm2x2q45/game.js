'use strict';
// Elements are static, so each lookup is cached (sync() runs every frame).
const domCache = new Map();
const $ = id => { let el = domCache.get(id); if (!el) { el = document.getElementById(id); domCache.set(id, el); } return el; };
const canvas = $('board'), ctx = canvas.getContext('2d'), game = new NightGame();
const letters = NightScene.letters, keyPos = NightScene.keyPos;
let facing = [0, 1], last = 0, moveTimer = 0;
const sound = new NightAudio();
let held = new Set(), best = 0, lastPhase = null;
// Leaving fullscreen (Esc or button) must not let the timer run unseen.
const display = new NightDisplay(canvas, () => { if (game.phase === 'playing') pause(); });
const scene = new NightScene(display);
try { best = Math.min(24, Math.max(0, Number(localStorage.getItem('karakurt-best')) || 0)); } catch (_) { /* Storage is optional. */ }
// Writes to the DOM only when the value really changed; the last shown value is remembered.
const shown = new Map();
const setText = (id, value) => { const text = String(value); if (shown.get(id) !== text) { shown.set(id, text); $(id).textContent = text; } };
const setDisabled = (el, value) => { if (el.disabled !== value) el.disabled = value; };
const directionButtons = [...document.querySelectorAll('[data-direction]')], chapterItems = [...document.querySelectorAll('.chapters li')];
const guide = $('guide-dialog'), about = $('about-dialog');
const menu = new NightMenu($('menu'), $('menu-canvas'), () => display.reducedMotion);
// While the menu covers the page, the game underneath must not be reachable by Tab or screen readers.
function setMenu(open) {
  if (open) menu.show(); else menu.hide();
  sound.setMode(open ? 'menu' : game.phase, game.chapter);
  for (const el of document.querySelectorAll('.topbar, main')) el.inert = open;
  if (open) $('menu-play').focus({ preventScroll: true });
}
function updateMenuRecord() { setText('menu-record', best ? `Рекорд ${best}/24 · 90 секунд · 3 главы` : '90 секунд · 3 главы · 24 опечатки'); }
let shownProgress = -1, shownLives = -1, shownUrgent = null, shownCombo = null, shownChapter = -1, shownWon = null;
const soundControls = new NightAudioControls(sound, () => { if (game.phase === 'playing') pause(); held.clear(); });
function say(speaker, line) { setText('speaker', speaker); setText('line', line); $('speaker').parentElement.parentElement.classList.toggle('human', speaker.startsWith('ЛЁША')); }
function move(dr, dc) { facing = [dr, dc]; if (game.move(dr, dc)) sound.play('move', game); sync(); }
function typo() { game.typo(); events(); sync(); }
function dash() { game.dash(...facing); events(); sync(); }
function weave() { game.weave(); events(); sync(); }
function sync() {
  const active = game.phase === 'playing';
  sound.setMode(menu.visible ? 'menu' : game.phase, game.chapter, game.time <= 15);
  setText('score', game.score); setText('time', Math.ceil(game.time));
  const urgent = game.time <= 15;
  if (urgent !== shownUrgent) { shownUrgent = urgent; $('time').classList.toggle('urgent', urgent); }
  setText('lives', '● '.repeat(game.lives).trim() + ' ○'.repeat(3 - game.lives));
  if (game.lives !== shownLives) { shownLives = game.lives; $('lives').setAttribute('aria-label', `Осталось жизней: ${game.lives}`); }
  if (game.score !== shownProgress) { shownProgress = game.score; $('progress').style.width = `${game.score / 24 * 100}%`; }
  setText('dash', game.cooldown > 0 ? `РЫВОК · ${game.cooldown.toFixed(1)}с` : 'РЫВОК · SHIFT');
  setDisabled($('dash'), !active || game.cooldown > 0);
  setDisabled($('typo'), !active);
  setDisabled($('web'), !active || game.silk <= 0 || game.webs.some(w => w.row === game.row && w.col === game.col));
  for (const b of directionButtons) setDisabled(b, !active);
  setText('silk', `${game.silk} / 3`);
  setText('combo', `СЕРИЯ ×${game.combo}${game.combo ? ` · ${game.comboTimer.toFixed(1)}с` : ''}`);
  const hot = game.combo >= 3;
  if (hot !== shownCombo) { shownCombo = hot; $('combo').classList.toggle('active', hot); }
  setText('position', letters[game.row][game.col]); setText('target-key', letters[game.target.row][game.target.col]);
  setText('objective', NightStory.chapters[game.chapter].goal.toUpperCase());
  const won = game.phase === 'won';
  if (game.chapter !== shownChapter || won !== shownWon) {
    shownChapter = game.chapter; shownWon = won;
    chapterItems.forEach((el, i) => {
      if (i === game.chapter) el.setAttribute('aria-current', 'step'); else el.removeAttribute('aria-current');
      el.classList.toggle('complete', i < game.chapter || won);
    });
  }
  if (game.phase !== lastPhase) { lastPhase = game.phase; showPhase(); }
}
function setCard(card) {
  setText('overline', card.tag); setText('title', card.title); setText('description', card.text);
}
function showPhase() {
  const playing = game.phase === 'playing'; $('overlay').hidden = playing; $('pause').hidden = !playing;
  $('to-menu').hidden = !['paused', 'won', 'lost'].includes(game.phase);
  $('results').hidden = true; $('rules').hidden = game.phase !== 'ready';
  if (playing) return;
  held.clear();
  if (game.phase === 'ready' || game.phase === 'chapter') {
    const chapter = NightStory.chapters[game.chapter]; setCard(chapter); setText('start', chapter.button);
    say(chapter.voice, chapter.line);
    setText('record', game.phase === 'ready' ? `90 секунд · 3 главы${best ? ` · рекорд ${best}/24` : ' · один маленький долг'}` : 'Время остановлено. Прочитай и продолжай, когда будешь готов.');
    if (game.phase === 'chapter') $('start').focus({ preventScroll: true });
    return;
  }
  if (game.phase === 'paused') {
    setCard({ tag: 'ТИШЕ. ОН НИЧЕГО НЕ ЗАМЕТИЛ.', title: 'Перерыв на паутинку.', text: 'Время, удары и ловушки замерли. Выдохни, расправь лапы и возвращайся. E — паутина на текущей клавише; Shift — рывок; пробел — опечатка на мятной цели.' });
    setText('start', 'ПРОДОЛЖИТЬ ↗'); setText('record', 'P / Esc — вернуться к игре');
  } else {
    if (game.score > best) { best = game.score; try { localStorage.setItem('karakurt-best', best); } catch (_) {} updateMenuRecord(); }
    const ending = NightStory.ending(game); setCard(ending); say(ending.voice, ending.line);
    $('results').hidden = false; $('results').replaceChildren();
    for (const [value, label] of [[`${game.score}/24`, 'опечатки'], [`×${game.maxCombo}`, 'лучшая серия'], [game.blocked, 'поймано ударов']]) {
      const stat = document.createElement('div'), strong = document.createElement('strong'), small = document.createElement('span');
      strong.textContent = value; small.textContent = label; stat.append(strong, small); $('results').append(stat);
    }
    setText('start', 'ЕЩЁ ОДНА НОЧЬ ↗');
    setText('record', `Рекорд: ${best}/24 · ${game.phase === 'won' ? `${Math.ceil(game.time)} с в запасе · человек сохранён` : 'Новый маршрут. Ещё один шанс.'}`);
    sound.play(game.phase === 'won' ? 'win' : 'lose');
  }
  $('start').focus({ preventScroll: true });
}
function events() {
  for (const event of game.events.splice(0)) {
    scene.onEvent(event, game);
    sound.play(event, game);
    if (event === 'typo') {
      setText('log', [`SyntaxError: unexpected spider at line ${game.score * 17}`, 'build failed: слишком много лап в аргументах', 'git commit -m "почему оно опять не работает"'][game.score % 3]);
      if (NightStory.beats[game.score]) say(...NightStory.beats[game.score]);
    }
    if (event === 'miss') setText('log', `Нужна клавиша ${letters[game.target.row][game.target.col]} — она подсвечена мятным.`);
    if (event === 'hurt') setText('log', 'Панцирь треснул. Серия сброшена. Уходи с красного!');
    if (event === 'web') setText('log', 'Паутина натянута на 6 секунд. Один удар — за её счёт.');
    if (event === 'block') setText('log', 'Палец запутался! Паутина поглотила удар.');
    if (event === 'silk') setText('log', 'Ещё одна нить! Каждые 4 опечатки пополняют шёлк.');
    if (event === 'combo') setText('log', `Серия ×${game.combo}! Автосборка отложена — до +3 секунд.`);
    if (event === 'sweep') setText('log', 'ШИРОКИЙ УДАР! Уходи в другой ряд клавиш.');
  }
}
function start() {
  held.clear(); moveTimer = 0;
  if (game.phase === 'paused') game.pause();
  else if (game.phase === 'chapter') { game.continueChapter(); setText('log', NightStory.chapters[game.chapter].threat); }
  else {
    game.start(); facing = [0, 1]; scene.reset(game);
    say(NightStory.chapters[0].voice, NightStory.chapters[0].line);
    setText('log', `Ты на ${letters[game.row][game.col]}. Пробел — и первая опечатка готова.`);
  }
  sync(); sound.play('start'); canvas.focus({ preventScroll: true });
}
function pause() {
  const before = game.phase; game.pause(); held.clear(); sync();
  if (game.phase !== before) sound.play(game.phase === 'playing' ? 'start' : 'pause');
  if (game.phase === 'playing') canvas.focus({ preventScroll: true });
}
$('start').onclick = start; $('pause').onclick = pause;
for (const [id, action] of [['typo', typo], ['dash', dash], ['web', weave]]) $(id).onclick = () => { action(); if (game.phase === 'playing') canvas.focus({ preventScroll: true }); };
// Audio controls and persisted mixer settings live in audio-ui.js.
const directions = { KeyW: [-1, 0], ArrowUp: [-1, 0], KeyS: [1, 0], ArrowDown: [1, 0], KeyA: [0, -1], ArrowLeft: [0, -1], KeyD: [0, 1], ArrowRight: [0, 1] };
// Field guide: opening it pauses the run; the dialog closes by Esc (native), the close button or a click on the backdrop.
$('help').onclick = () => {
  if (game.phase === 'playing') pause();
  held.clear();
  if (typeof guide.showModal === 'function' && !guide.open) guide.showModal(); else guide.setAttribute('open', '');
};
$('close-help').onclick = () => guide.close();
guide.addEventListener('click', e => { if (e.target === guide) guide.close(); });
// Main menu: Play goes to the chapter card (story + rules); "В меню" abandons the current run.
$('menu-play').onclick = () => { setMenu(false); $('start').focus({ preventScroll: true }); };
$('menu-help').onclick = () => $('help').click();
$('menu-about').onclick = () => { if (typeof about.showModal === 'function' && !about.open) about.showModal(); else about.setAttribute('open', ''); };
$('close-about').onclick = () => about.close();
about.addEventListener('click', e => { if (e.target === about) about.close(); });
$('to-menu').onclick = () => { held.clear(); game.reset(); scene.reset(game); sync(); setMenu(true); };
// Menu toggles drive the real toolbar buttons and mirror their label and state.
for (const [source, copy] of [['motion', 'menu-motion'], ['fullscreen', 'menu-fullscreen']]) {
  const from = $(source), to = $(copy);
  const mirror = () => { to.textContent = from.textContent.replace(/\s+/g, ' ').trim(); to.setAttribute('aria-pressed', from.getAttribute('aria-pressed') || 'false'); to.title = from.title; };
  new MutationObserver(mirror).observe(from, { childList: true, subtree: true, characterData: true, attributes: true });
  to.onclick = () => from.click(); mirror();
}
updateMenuRecord(); setMenu(true);
window.addEventListener('keydown', e => {
  if (guide.open || about.open || soundControls.dialog.open) return; // keys belong to the dialog while it is open
  if (['INPUT', 'SELECT', 'TEXTAREA'].includes(e.target.tagName)) return;
  if (e.ctrlKey || e.altKey || e.metaKey) return;
  if (e.code === 'KeyF' && !e.repeat && e.target.tagName !== 'INPUT') { e.preventDefault(); display.toggleFullscreen(); return; }
  if (menu.visible) { if (e.code === 'Enter' && !e.repeat && e.target.tagName !== 'BUTTON') { e.preventDefault(); $('menu-play').click(); } return; }
  if (['KeyP', 'Escape'].includes(e.code)) { if (!e.repeat) pause(); e.preventDefault(); return; }
  if (game.phase !== 'playing' || (!(e.code in directions) && !['Space', 'ShiftLeft', 'ShiftRight', 'KeyE'].includes(e.code))) return;
  if (e.code === 'Space' && e.target.tagName === 'BUTTON') return;
  e.preventDefault(); if (e.repeat) return;
  if (directions[e.code]) { held.add(e.code); move(...directions[e.code]); moveTimer = .16; }
  else if (e.code === 'Space') typo(); else if (e.code === 'KeyE') weave(); else dash();
});
window.addEventListener('keyup', e => held.delete(e.code));
window.addEventListener('blur', () => { sound.setBackground(true); held.clear(); if (game.phase === 'playing') pause(); });
window.addEventListener('focus', () => sound.setBackground(document.hidden));
document.addEventListener('visibilitychange', () => {
  sound.setBackground(document.hidden || !document.hasFocus());
  if (document.hidden && game.phase === 'playing') pause();
});
window.addEventListener('pagehide', () => sound.setBackground(true));
window.addEventListener('pageshow', () => sound.setBackground(document.hidden));
canvas.addEventListener('pointerdown', e => {
  if (game.phase !== 'playing') return;
  const { x, y } = display.point(e.clientX, e.clientY);
  let nearest, distance = Infinity;
  for (let r = 0; r < 3; r++) for (let c = 0; c < 10; c++) { const p = keyPos(r, c), d = Math.hypot(p.x - x, p.y - y); if (d < distance) { nearest = [r, c]; distance = d; } }
  if (distance > 65) return;
  const [r, c] = nearest;
  if (r === game.row && c === game.col) typo(); else if (r !== game.row) move(Math.sign(r - game.row), 0); else move(0, Math.sign(c - game.col));
  if (game.phase === 'playing') canvas.focus({ preventScroll: true });
});
document.querySelectorAll('[data-direction]').forEach(button => {
  const code = button.dataset.direction;
  button.addEventListener('pointerdown', e => {
    if (game.phase !== 'playing') return;
    e.preventDefault(); button.setPointerCapture(e.pointerId); held.add(code); move(...directions[code]); moveTimer = .2;
  });
  for (const event of ['pointerup', 'pointercancel', 'lostpointercapture']) button.addEventListener(event, () => held.delete(code));
  button.onclick = e => { if (e.detail === 0) move(...directions[code]); };
});
function frame(now) {
  const dt = Math.min((now - (last || now)) / 1000, .05); last = now;
  if (game.phase === 'playing') { moveTimer -= dt; if (moveTimer <= 0 && held.size) { const code = [...held].at(-1); move(...directions[code]); moveTimer = .13; } game.tick(dt); events(); sync(); }
  scene.update(game.phase === 'paused' ? 0 : dt, game); scene.draw(ctx, game); requestAnimationFrame(frame);
}
sync();
requestAnimationFrame(frame);
